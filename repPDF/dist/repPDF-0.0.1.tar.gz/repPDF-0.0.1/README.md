## Report Lab PDF Binder package for easy and quick pdf generation
- Supports Pandas Dataframes, Body text, header text, footer text, static images(FileIO)
